const fs = require('fs');
const path = require('path');
const { logEvent } = require('./logger');

// Resolve a data JSON path from the backend/data directory.
function dataFile(fileName) {
    return path.join(__dirname, '..', 'data', fileName);
}

// Read JSON safely and fall back to a default value.
function readJson(fileName, fallback = []) {
    const filePath = dataFile(fileName);
    try {
        const raw = fs.readFileSync(filePath, 'utf8');
        return raw.trim() ? JSON.parse(raw) : fallback;
    } catch (error) {
        // Log read/parse failures to identify why a dataset may reset.
        logEvent('json.read.failed', {
            fileName,
            filePath,
            message: error.message,
        });
        return fallback;
    }
}

// Write JSON with readable formatting.
function writeJson(fileName, value) {
    const filePath = dataFile(fileName);
    try {
        const body = JSON.stringify(value, null, 2);
        fs.writeFileSync(filePath, body, 'utf8');
        // Log successful persistence so we can trace save requests.
        logEvent('json.write.ok', {
            fileName,
            filePath,
            bytes: Buffer.byteLength(body, 'utf8'),
        });
    } catch (error) {
        logEvent('json.write.failed', {
            fileName,
            filePath,
            message: error.message,
        });
        throw error;
    }
}

module.exports = {
    readJson,
    writeJson,
};
