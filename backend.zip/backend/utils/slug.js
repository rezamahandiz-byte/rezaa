// Convert any text to a URL-safe kebab-case slug.
function slugify(value = '') {
    return String(value)
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
}

// Ensure slug uniqueness by appending a numeric suffix when needed.
function uniqueSlug(base, isTaken) {
    const cleanBase = base || 'song';
    if (!isTaken(cleanBase)) return cleanBase;
    let counter = 2;
    while (isTaken(`${cleanBase}-${counter}`)) {
        counter += 1;
    }
    return `${cleanBase}-${counter}`;
}

module.exports = {
    slugify,
    uniqueSlug,
};
