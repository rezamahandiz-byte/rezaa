const crypto = require('crypto');

// Extract a stable client IP address from proxy headers or request socket.
function getClientIp(req) {
    const forwarded = req.headers['x-forwarded-for'];
    const firstForwarded = Array.isArray(forwarded)
        ? forwarded[0]
        : String(forwarded || '').split(',')[0].trim();
    const ip = firstForwarded || req.ip || req.socket?.remoteAddress || 'unknown';
    return String(ip).replace('::ffff:', '');
}

// Hash identity values before persistence to avoid storing plain IP text.
function hashIdentity(value) {
    return crypto.createHash('sha256').update(String(value || 'unknown')).digest('hex');
}

module.exports = {
    getClientIp,
    hashIdentity,
};
