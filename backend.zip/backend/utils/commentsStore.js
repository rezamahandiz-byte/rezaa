const { readJson, writeJson } = require('./jsonStore');

const COMMENTS_FILE = 'comments.json';

// Normalize one comment row to a consistent schema.
function normalizeComment(raw, fallbackId = 0) {
    const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    const id = Number(source.id) || Number(fallbackId) || Date.now();
    const name = String(source.name || source.author || '').trim();
    const text = String(source.text || source.comment || '').replace(/\r\n/g, '\n').trim();
    const songTitle = String(source.songTitle || '').trim();
    const likes = Math.max(0, Number(source.likes || 0));
    const createdAt = String(source.createdAt || new Date().toISOString());
    const ipHash = String(source.ipHash || '');
    const likedBy = Array.isArray(source.likedBy)
        ? source.likedBy.filter((entry) => typeof entry === 'string' && entry.trim())
        : [];

    return {
        id,
        name,
        text,
        songTitle,
        likes,
        createdAt,
        ipHash,
        likedBy,
    };
}

// Normalize comments array from JSON storage.
function normalizeComments(input) {
    if (!Array.isArray(input)) return [];
    return input.map((item, index) => normalizeComment(item, index + 1));
}

// Read comments from comments.json with a stable schema.
function readComments() {
    const rows = readJson(COMMENTS_FILE, []);
    return normalizeComments(rows);
}

// Persist comments to comments.json after normalization.
function writeComments(rows) {
    writeJson(COMMENTS_FILE, normalizeComments(rows));
}

// Public-facing comment shape (hide identity metadata).
function publicComment(comment) {
    const normalized = normalizeComment(comment);
    return {
        id: normalized.id,
        name: normalized.name,
        text: normalized.text,
        songTitle: normalized.songTitle,
        likes: normalized.likes,
        createdAt: normalized.createdAt,
    };
}

// Sort comments by likes desc, then by latest creation date.
function sortComments(rows) {
    return [...rows].sort((a, b) => {
        const likeDiff = Number(b.likes || 0) - Number(a.likes || 0);
        if (likeDiff !== 0) return likeDiff;
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
    });
}

// Generate next numeric comment id.
function nextCommentId(rows) {
    if (!Array.isArray(rows) || rows.length === 0) return 1;
    return Math.max(...rows.map((item) => Number(item.id) || 0)) + 1;
}

module.exports = {
    normalizeComment,
    readComments,
    writeComments,
    publicComment,
    sortComments,
    nextCommentId,
};
