const fs = require('fs');
const path = require('path');
const { sendLogToAdmin } = require('../services/telegramNotifier');

const LOG_DIR = path.join(__dirname, '..', 'logs');
const LOG_FILE = path.join(LOG_DIR, 'admin-debug.log');
const MAX_LOG_SIZE_BYTES = 1024 * 1024; // 1MB
const KEEP_LOG_SIZE_BYTES = 256 * 1024; // keep the newest 256KB when trimming

const IMPORTANT_EVENTS = new Set([
    'server.started',
    'http.error',
    'json.read.failed',
    'json.write.failed',
    'admin.auth.denied',
    'process.unhandledRejection',
    'process.uncaughtException',
]);

// Ensure log directory/file exists before writing diagnostic events.
function ensureLogTarget() {
    if (!fs.existsSync(LOG_DIR)) {
        fs.mkdirSync(LOG_DIR, { recursive: true });
    }
    if (!fs.existsSync(LOG_FILE)) {
        fs.writeFileSync(LOG_FILE, '', 'utf8');
    }
}

// Skip very noisy informational events so the log file does not grow too fast.
function shouldSkipPersist(event, details = {}) {
    if (event === 'admin.auth.accepted') return true;
    if (String(event).endsWith('.list.requested')) return true;
    if (event === 'http.request') {
        const method = String(details.method || '').toUpperCase();
        const status = Number(details.status || 0);
        if (method === 'GET' && status >= 200 && status < 400) return true;
    }
    return false;
}

// Keep only the latest part of the file when it grows beyond max size.
function trimLogIfNeeded() {
    try {
        const stats = fs.statSync(LOG_FILE);
        if (stats.size <= MAX_LOG_SIZE_BYTES) return;
        const raw = fs.readFileSync(LOG_FILE, 'utf8');
        const trimmed = raw.slice(-KEEP_LOG_SIZE_BYTES);
        fs.writeFileSync(LOG_FILE, trimmed, 'utf8');
    } catch (_error) {
        // Ignore trim failures to avoid breaking runtime behavior.
    }
}

// Send selected high-signal events to admin Telegram notifications.
function notifyImportantEvent(event, details = {}) {
    if (!IMPORTANT_EVENTS.has(event)) return;
    sendLogToAdmin({
        event,
        time: new Date().toISOString(),
        details,
    }).catch(() => {
        // Never fail request flow if Telegram delivery is unavailable.
    });
}

// Write one JSON-line log entry for easier debugging and parsing.
function logEvent(event, details = {}) {
    try {
        notifyImportantEvent(event, details);
        if (shouldSkipPersist(event, details)) return;
        ensureLogTarget();
        trimLogIfNeeded();
        const record = { ts: new Date().toISOString(), event, ...details };
        fs.appendFileSync(LOG_FILE, `${JSON.stringify(record)}\n`, 'utf8');
    } catch (_error) {
        // Avoid crashing request lifecycle because of logging failures.
    }
}

module.exports = {
    LOG_FILE,
    logEvent,
};
