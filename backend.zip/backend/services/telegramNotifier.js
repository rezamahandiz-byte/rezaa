const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');

const TELEGRAM_TOKEN = '8055341163:AAHI7dePYj-YvbVRvmVV5uvol-2o8WSx9lc';
const ADMIN_CHAT_ID = '@mash_izaaa';
const COMMENTS_CHANNEL_ID = '@reza20200110';
const TELEGRAM_SETTINGS_FILE = path.join(__dirname, '..', 'data', 'telegram.json');

let bot = null;
const TELEGRAM_REQUEST_TIMEOUT_MS = 12000;

// Create one shared Telegram bot instance for notification sends.
function getBot() {
    if (bot) return bot;
    try {
        const proxy = String(process.env.HTTPS_PROXY || process.env.HTTP_PROXY || '').trim();
        const requestOptions = { timeout: TELEGRAM_REQUEST_TIMEOUT_MS };
        // Use proxy env vars when provided, useful for filtered networks.
        if (proxy) requestOptions.proxy = proxy;
        bot = new TelegramBot(TELEGRAM_TOKEN, {
            polling: false,
            request: requestOptions,
        });
    } catch (_error) {
        bot = null;
    }
    return bot;
}

// Trim long values so Telegram messages stay readable.
function clip(value, max = 1200) {
    const text = String(value || '');
    if (text.length <= max) return text;
    return `${text.slice(0, max)}...`;
}

// Read admin/channel chat IDs from telegram.json (last row wins), with safe fallbacks.
function readTelegramTargets() {
    try {
        if (!fs.existsSync(TELEGRAM_SETTINGS_FILE)) {
            return {
                adminChatId: ADMIN_CHAT_ID,
                commentsChannelId: COMMENTS_CHANNEL_ID,
            };
        }

        const raw = fs.readFileSync(TELEGRAM_SETTINGS_FILE, 'utf8');
        const parsed = raw.trim() ? JSON.parse(raw) : [];
        const rows = Array.isArray(parsed) ? parsed : [parsed];
        const latest = rows.length > 0 ? rows[rows.length - 1] : {};
        const adminChatId = String(latest.AdminChatId || latest.adminChatId || ADMIN_CHAT_ID).trim();
        const commentsChannelId = String(
            latest.CommentsChannelId || latest.commentsChannelId || COMMENTS_CHANNEL_ID
        ).trim();

        return {
            adminChatId: adminChatId || ADMIN_CHAT_ID,
            commentsChannelId: commentsChannelId || COMMENTS_CHANNEL_ID,
        };
    } catch (_error) {
        return {
            adminChatId: ADMIN_CHAT_ID,
            commentsChannelId: COMMENTS_CHANNEL_ID,
        };
    }
}

// Guarantee each Telegram API call resolves within a fixed timeout window.
function withTimeout(promise, timeoutMs = TELEGRAM_REQUEST_TIMEOUT_MS) {
    let timer = null;
    const timeoutPromise = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('Telegram request timeout')), timeoutMs);
    });
    return Promise.race([promise, timeoutPromise]).finally(() => {
        if (timer) clearTimeout(timer);
    });
}

// Safe message sender that never throws to caller.
async function sendTelegramMessage(chatId, text) {
    try {
        const instance = getBot();
        if (!instance || !chatId || !text) return false;
        await withTimeout(
            instance.sendMessage(chatId, clip(text, 3900), {
                disable_web_page_preview: true,
            }),
            TELEGRAM_REQUEST_TIMEOUT_MS
        );
        return true;
    } catch (_error) {
        return false;
    }
}

// Send newly created comment details to Telegram channel/group.
async function sendCommentToChannel({ authorName, commentText, songTitle, songLink }) {
    try {
        const { commentsChannelId } = readTelegramTargets();
        const message = [
            'نظر جدید در سایت',
            `نام نویسنده: ${authorName || 'ناشناس'}`,
            `متن نظر: ${commentText || '-'}`,
            `آهنگ موردنظر: ${songTitle || '-'}`,
            songLink ? `لینک آهنگ: ${songLink}` : null,
        ].filter(Boolean).join('\n');
        return await sendTelegramMessage(commentsChannelId, message);
    } catch (_error) {
        // Do not break request flow when Telegram is unavailable.
        return false;
    }
}

// Send backend errors to admin private chat.
async function sendErrorToAdmin({ message, path, method, time, stack }) {
    try {
        const { adminChatId } = readTelegramTargets();
        const text = [
            'خطای بک‌اند',
            `زمان: ${time || new Date().toISOString()}`,
            `متد: ${method || 'نامشخص'}`,
            `مسیر: ${path || '-'}`,
            `پیام: ${message || 'خطای نامشخص'}`,
            `استک: ${clip(stack || '-', 1800)}`,
        ].join('\n');
        return await sendTelegramMessage(adminChatId, text);
    } catch (_error) {
        // Never crash server because of Telegram failures.
        return false;
    }
}

// Send important operational logs to admin chat.
async function sendLogToAdmin({ event, details, time }) {
    try {
        const { adminChatId } = readTelegramTargets();
        const text = [
            'لاگ مهم سیستم',
            `زمان: ${time || new Date().toISOString()}`,
            `رویداد: ${event || 'نامشخص'}`,
            `جزئیات: ${clip(JSON.stringify(details || {}), 1800)}`,
        ].join('\n');
        return await sendTelegramMessage(adminChatId, text);
    } catch (_error) {
        // Keep server alive even if Telegram send fails.
        return false;
    }
}

// Send startup announcements to both admin and group when bot is activated.
async function sendStartupAnnouncements({ port }) {
    try {
        const { adminChatId, commentsChannelId } = readTelegramTargets();
        const startedAt = new Date().toISOString();
        const adminText = [
            'ربات با موفقیت فعال شد',
            `زمان: ${startedAt}`,
            `پورت سرور: ${port}`,
            'وضعیت: آماده دریافت خطاها و لاگ‌ها',
        ].join('\n');
        const groupText = [
            'ربات موزیک فعال شد',
            `زمان فعال‌سازی: ${startedAt}`,
            'از این لحظه نظرات جدید سایت در این گروه ارسال می‌شود.',
        ].join('\n');

        const [adminResult, groupResult] = await Promise.allSettled([
            sendTelegramMessage(adminChatId, adminText),
            sendTelegramMessage(commentsChannelId, groupText),
        ]);

        return {
            adminOk: adminResult.status === 'fulfilled' ? Boolean(adminResult.value) : false,
            groupOk: groupResult.status === 'fulfilled' ? Boolean(groupResult.value) : false,
        };
    } catch (_error) {
        return { adminOk: false, groupOk: false };
    }
}

module.exports = {
    TELEGRAM_TOKEN,
    ADMIN_CHAT_ID,
    COMMENTS_CHANNEL_ID,
    sendCommentToChannel,
    sendErrorToAdmin,
    sendLogToAdmin,
    sendStartupAnnouncements,
};
