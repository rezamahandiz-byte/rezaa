const express = require('express');
const cors = require('cors');
const { requireAdminKey } = require('./middleware/adminAuth');
const { logEvent, LOG_FILE } = require('./utils/logger');
const { sendErrorToAdmin, sendStartupAnnouncements } = require('./services/telegramNotifier');

const app = express();
// Trust proxy headers so IP-based comment limits work correctly behind hosting proxies.
app.set('trust proxy', true);

// Enable CORS so frontend clients can call backend APIs.
app.use(cors());
// Parse JSON request bodies for CRUD and analytics routes.
app.use(express.json());
// Log every API request/response pair to debug persistence issues end-to-end.
app.use((req, res, next) => {
    const startedAt = Date.now();
    res.on('finish', () => {
        logEvent('http.request', {
            method: req.method,
            path: req.originalUrl,
            status: res.statusCode,
            durationMs: Date.now() - startedAt,
            ip: req.ip,
        });
    });
    next();
});

// Expose public read-only content APIs used by the website.
app.use('/api/content', require('./routes/content'));
// Expose public comments APIs (list, create, like).
app.use('/api/content/comments', require('./routes/commentsPublic'));
// Expose dynamic song page API by slug (example: /api/songs/my-song).
app.use('/api/songs', require('./routes/publicSongs'));

// Expose admin authentication verification endpoint.
app.use('/api/admin/auth', require('./routes/adminAuth'));
// Expose admin analytics endpoints for visits and session duration.
app.use('/api/admin/analytics', require('./routes/adminAnalytics'));

// Protect songs admin CRUD routes with shared admin key middleware.
app.use('/api/admin/songs', requireAdminKey, require('./routes/songs'));
// Protect ads admin CRUD routes with shared admin key middleware.
app.use('/api/admin/ads', requireAdminKey, require('./routes/ads'));
// Protect legacy suggested admin CRUD routes with shared admin key.
app.use('/api/admin/suggested', requireAdminKey, require('./routes/suggested'));
// Protect additional variable CRUD routes mapped to suggested.json.
app.use('/api/admin/other_variables', requireAdminKey, require('./routes/otherVariables'));
// Protect NavBar about-menu CRUD routes mapped to navMenu.json.
app.use('/api/admin/nav-menu', requireAdminKey, require('./routes/navMenu'));
// Protect comments moderation CRUD routes for admin panel.
app.use('/api/admin/comments', requireAdminKey, require('./routes/commentsAdmin'));
// Protect Telegram target settings CRUD routes for admin notifications.
app.use('/api/admin/telegram', requireAdminKey, require('./routes/telegramSettings'));

// Return JSON errors instead of HTML so frontend never crashes on JSON parsing.
app.use((err, req, res, next) => {
    console.error('API error:', err);
    logEvent('http.error', {
        method: req.method,
        path: req.originalUrl,
        message: err.message,
        stack: err.stack,
    });
    // Forward backend API errors to Telegram admin chat for immediate visibility.
    sendErrorToAdmin({
        message: err.message,
        path: req.originalUrl,
        method: req.method,
        time: new Date().toISOString(),
        stack: err.stack,
    }).catch(() => {
        // Keep API stable even if Telegram is temporarily unavailable.
    });
    const status = err.status || 500;
    res.status(status).json({
        message: err.message || 'خطای داخلی سرور رخ داد.',
        code: 'API_ERROR',
    });
});

const port = process.env.PORT || 4000;
// Start the backend API server.
app.listen(port, () => {
    console.log(`Admin API listening on port ${port}`);
    console.log(`Debug log file: ${LOG_FILE}`);
    logEvent('server.started', { port, logFile: LOG_FILE });
    // Notify both admin and group that bot/server are active at startup.
    sendStartupAnnouncements({ port })
        .then((result) => logEvent('telegram.startup.sent', result))
        .catch(() => {
            // Keep startup stable even if Telegram delivery fails.
        });
});

// Catch any unhandled promise rejection and report it to logs + Telegram.
process.on('unhandledRejection', (reason) => {
    const message = reason instanceof Error ? reason.message : String(reason);
    const stack = reason instanceof Error ? reason.stack : '';
    logEvent('process.unhandledRejection', { message, stack });
    sendErrorToAdmin({
        message,
        path: 'process.unhandledRejection',
        method: 'SYSTEM',
        time: new Date().toISOString(),
        stack,
    }).catch(() => {});
});

// Catch uncaught exceptions and report them to logs + Telegram.
process.on('uncaughtException', (error) => {
    logEvent('process.uncaughtException', {
        message: error.message,
        stack: error.stack,
    });
    sendErrorToAdmin({
        message: error.message,
        path: 'process.uncaughtException',
        method: 'SYSTEM',
        time: new Date().toISOString(),
        stack: error.stack,
    }).catch(() => {});
});
