const { logEvent } = require('../utils/logger');

// Protect admin APIs by checking the shared admin key header.
function requireAdminKey(req, res, next) {
    const configuredKey = process.env.ADMIN_KEY || 'weblom';
    const providedKey = req.header('x-admin-key') || '';

    if (providedKey !== configuredKey) {
        // Record unauthorized access details to diagnose failed save requests.
        logEvent('admin.auth.denied', {
            path: req.originalUrl,
            method: req.method,
            hasKey: Boolean(providedKey),
            keyLength: providedKey.length,
        });
        return res.status(401).json({ message: 'دسترسی ادمین غیرمجاز است.' });
    }

    logEvent('admin.auth.accepted', {
        path: req.originalUrl,
        method: req.method,
    });
    return next();
}

module.exports = {
    requireAdminKey,
};
