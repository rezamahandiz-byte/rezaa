const { readJson, writeJson } = require('../utils/jsonStore');

const ANALYTICS_FILE = 'analytics.json';

// Increment total admin visits for each session start event.
function trackAdminVisit(req, res, next) {
    const analytics = readJson(ANALYTICS_FILE, { visits: 0, totalTimeMs: 0 });
    analytics.visits = Number(analytics.visits || 0) + 1;
    writeJson(ANALYTICS_FILE, analytics);
    next();
}

// Add a reported duration to the cumulative admin time metric.
function trackAdminTime(req, res, next) {
    const durationMs = Number(req.body?.durationMs || 0);
    const analytics = readJson(ANALYTICS_FILE, { visits: 0, totalTimeMs: 0 });
    analytics.totalTimeMs = Number(analytics.totalTimeMs || 0) + Math.max(0, durationMs);
    writeJson(ANALYTICS_FILE, analytics);
    next();
}

module.exports = {
    trackAdminVisit,
    trackAdminTime,
};
