const createCrudRouter = require('./createCrudRouter');

// Admin CRUD routes for Telegram destination chat IDs in telegram.json.
module.exports = createCrudRouter('telegram.json');
