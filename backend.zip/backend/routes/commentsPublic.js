const express = require('express');
const { getClientIp, hashIdentity } = require('../utils/clientIdentity');
const { logEvent } = require('../utils/logger');
const { slugify } = require('../utils/slug');
const { sendCommentToChannel } = require('../services/telegramNotifier');
const {
    readComments,
    writeComments,
    publicComment,
    sortComments,
    nextCommentId,
    normalizeComment,
} = require('../utils/commentsStore');

const router = express.Router();

// GET public comments sorted by likes descending.
router.get('/', (req, res) => {
    const comments = sortComments(readComments()).map(publicComment);
    res.json(comments);
});

// POST create one public comment (one comment per IP).
router.post('/', (req, res) => {
    const payload = req.body && typeof req.body === 'object' ? req.body : {};
    const name = String(payload.name || '').trim();
    const text = String(payload.text || '').replace(/\r\n/g, '\n').trim();
    const songTitle = String(payload.songTitle || '').trim();
    const songSlug = String(payload.songSlug || '').trim();
    const songLinkInput = String(payload.songLink || '').trim();

    if (!name || !text) {
        return res.status(400).json({ message: 'وارد کردن نام و متن نظر الزامی است.' });
    }

    const ipHash = hashIdentity(getClientIp(req));
    const comments = readComments();
    const alreadyCommented = comments.some((item) => item.ipHash === ipHash);

    if (alreadyCommented) {
        return res.status(409).json({ message: 'از هر IP فقط یک نظر ثبت می‌شود.' });
    }

    const created = normalizeComment({
        id: nextCommentId(comments),
        name,
        text,
        songTitle,
        likes: 0,
        createdAt: new Date().toISOString(),
        ipHash,
        likedBy: [],
    });

    comments.push(created);
    writeComments(comments);
    logEvent('comments.created', { id: created.id, name: created.name, songTitle: created.songTitle || '' });

    // Send readable Telegram notification for every new comment without blocking response flow.
    const derivedSlug = songSlug || (songTitle ? slugify(songTitle) : '');
    const songLink = songLinkInput || (derivedSlug ? `/song/${derivedSlug}` : '');
    sendCommentToChannel({
        authorName: created.name,
        commentText: created.text,
        songTitle: created.songTitle,
        songLink,
    }).catch(() => {
        // Do not fail comment creation if Telegram delivery fails.
    });

    return res.status(201).json(publicComment(created));
});

// POST add one like to a comment (one like per IP per comment).
router.post('/:id/like', (req, res) => {
    const id = Number(req.params.id);
    const comments = readComments();
    const index = comments.findIndex((item) => Number(item.id) === id);

    if (index < 0) {
        return res.status(404).json({ message: 'نظر پیدا نشد.' });
    }

    const ipHash = hashIdentity(getClientIp(req));
    const likedBy = Array.isArray(comments[index].likedBy) ? comments[index].likedBy : [];

    if (likedBy.includes(ipHash)) {
        return res.status(409).json({ message: 'قبلاً این نظر را لایک کرده‌اید.' });
    }

    comments[index].likedBy = [...likedBy, ipHash];
    comments[index].likes = Math.max(0, Number(comments[index].likes || 0)) + 1;
    writeComments(comments);
    logEvent('comments.liked', { id, likes: comments[index].likes });
    return res.json({ id, likes: comments[index].likes });
});

module.exports = router;
