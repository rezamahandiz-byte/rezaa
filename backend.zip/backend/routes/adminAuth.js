const express = require('express');
const { requireAdminKey } = require('../middleware/adminAuth');

const router = express.Router();

// Verify admin credentials and return success when key is valid.
router.post('/verify', requireAdminKey, (req, res) => {
    res.json({ success: true });
});

module.exports = router;
