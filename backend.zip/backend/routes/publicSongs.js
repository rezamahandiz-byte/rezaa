const express = require('express');
const { readJson, writeJson } = require('../utils/jsonStore');
const { slugify, uniqueSlug } = require('../utils/slug');

const router = express.Router();

// GET one song by generated slug for dynamic song pages.
router.get('/:slug', (req, res) => {
    const songs = readJson('songs.json', []);
    // Backfill missing slug/path so older records can be resolved by URL.
    let changed = false;
    const withRoutes = songs.map((song) => {
        if (song.slug && song.path) return song;
        const base = slugify(song.MiusicTitle || '') || `song-${song.id}`;
        const slugCandidate = uniqueSlug(base, (candidate) =>
            songs.some((s) => s !== song && s.slug === candidate)
        );
        changed = true;
        return { ...song, slug: slugCandidate, path: `/song/${slugCandidate}` };
    });
    if (changed) writeJson('songs.json', withRoutes);

    const slug = String(req.params.slug || '').trim().toLowerCase();
    const song = withRoutes.find((item) => String(item.slug || '').toLowerCase() === slug);

    if (!song) {
        return res.status(404).json({ message: 'آهنگ پیدا نشد.' });
    }

    return res.json(song);
});

module.exports = router;
