const express = require('express');
const { readJson, writeJson } = require('../utils/jsonStore');

// Normalize any incoming payload to a plain object to avoid malformed writes.
function normalizePayload(payload) {
    return payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
}

// Build a reusable CRUD router for a JSON collection file.
function createCrudRouter(fileName) {
    const router = express.Router();

    // GET all records from the target JSON file.
    router.get('/', (req, res) => {
        res.json(readJson(fileName, []));
    });

    // POST create a new record with a generated numeric id.
    router.post('/', (req, res) => {
        const items = readJson(fileName, []);
        const payload = normalizePayload(req.body);
        const item = { id: Date.now(), ...payload };
        items.push(item);
        writeJson(fileName, items);
        res.status(201).json(item);
    });

    // PUT update one record by id while keeping existing fields.
    router.put('/:id', (req, res) => {
        const id = Number(req.params.id);
        const items = readJson(fileName, []);
        const payload = normalizePayload(req.body);
        const index = items.findIndex((entry) => Number(entry.id) === id);

        if (index < 0) {
            return res.status(404).json({ message: 'آیتم پیدا نشد.' });
        }

        items[index] = { ...items[index], ...payload, id };
        writeJson(fileName, items);
        return res.json(items[index]);
    });

    // DELETE remove one record by id from the JSON collection.
    router.delete('/:id', (req, res) => {
        const id = Number(req.params.id);
        const items = readJson(fileName, []);
        const next = items.filter((entry) => Number(entry.id) !== id);
        writeJson(fileName, next);
        res.json({ success: true });
    });

    return router;
}

module.exports = createCrudRouter;
