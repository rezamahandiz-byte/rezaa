const createCrudRouter = require('./createCrudRouter');

// Admin CRUD routes for additional dynamic variables in suggested.json.
module.exports = createCrudRouter('suggested.json');
