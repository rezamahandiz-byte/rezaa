const createCrudRouter = require('./createCrudRouter');

// Admin CRUD routes for suggested.json records.
module.exports = createCrudRouter('suggested.json');
