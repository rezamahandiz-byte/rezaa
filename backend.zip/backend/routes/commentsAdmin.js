const express = require('express');
const { logEvent } = require('../utils/logger');
const {
    readComments,
    writeComments,
    sortComments,
    publicComment,
    nextCommentId,
    normalizeComment,
} = require('../utils/commentsStore');

const router = express.Router();

// GET admin comments list sorted by likes.
router.get('/', (req, res) => {
    res.json(sortComments(readComments()).map(publicComment));
});

// POST create a comment from admin panel.
router.post('/', (req, res) => {
    const payload = req.body && typeof req.body === 'object' ? req.body : {};
    const name = String(payload.name || '').trim();
    const text = String(payload.text || '').replace(/\r\n/g, '\n').trim();

    if (!name || !text) {
        return res.status(400).json({ message: 'نام و متن نظر الزامی است.' });
    }

    const comments = readComments();
    const created = normalizeComment({
        id: nextCommentId(comments),
        name,
        text,
        songTitle: String(payload.songTitle || '').trim(),
        likes: Math.max(0, Number(payload.likes || 0)),
        createdAt: new Date().toISOString(),
        ipHash: '',
        likedBy: [],
    });

    comments.push(created);
    writeComments(comments);
    logEvent('admin.comments.created', { id: created.id });
    return res.status(201).json(publicComment(created));
});

// PUT update one admin comment by id.
router.put('/:id', (req, res) => {
    const id = Number(req.params.id);
    const payload = req.body && typeof req.body === 'object' ? req.body : {};
    const comments = readComments();
    const index = comments.findIndex((item) => Number(item.id) === id);

    if (index < 0) {
        return res.status(404).json({ message: 'نظر پیدا نشد.' });
    }

    const previous = comments[index];
    const updated = normalizeComment({
        ...previous,
        ...payload,
        id,
        likes: payload.likes !== undefined ? Math.max(0, Number(payload.likes || 0)) : previous.likes,
        ipHash: previous.ipHash,
        likedBy: previous.likedBy,
        createdAt: previous.createdAt,
    });

    comments[index] = updated;
    writeComments(comments);
    logEvent('admin.comments.updated', { id });
    return res.json(publicComment(updated));
});

// DELETE remove one comment from admin panel.
router.delete('/:id', (req, res) => {
    const id = Number(req.params.id);
    const comments = readComments();
    const next = comments.filter((item) => Number(item.id) !== id);
    writeComments(next);
    logEvent('admin.comments.deleted', { id });
    res.json({ success: true });
});

module.exports = router;
