const express = require('express');
const { readJson, writeJson } = require('../utils/jsonStore');
const { slugify, uniqueSlug } = require('../utils/slug');

const router = express.Router();

// Public GET endpoint for songs consumed by frontend music listings.
router.get('/songs', (req, res) => {
    const songs = readJson('songs.json', []);
    // Backfill slug/path so public song lists can link to dynamic URLs.
    let changed = false;
    const withRoutes = songs.map((song) => {
        if (song.slug && song.path) return song;
        const base = slugify(song.MiusicTitle || '') || `song-${song.id}`;
        const slug = uniqueSlug(base, (candidate) => songs.some((other) => other !== song && other.slug === candidate));
        changed = true;
        return { ...song, slug, path: `/song/${slug}` };
    });
    if (changed) writeJson('songs.json', withRoutes);
    res.json(withRoutes);
});

// Public GET endpoint for advertisements consumed by frontend ad widgets.
router.get('/ads', (req, res) => {
    res.json(readJson('ads.json', []));
});

// Public GET endpoint for suggested items consumed by suggested songs UI.
router.get('/suggested', (req, res) => {
    res.json(readJson('suggested.json', []));
});

// Public GET endpoint for dynamic NavBar about-menu items.
router.get('/nav-menu', (req, res) => {
    res.json(readJson('navMenu.json', []));
});

module.exports = router;
