const express = require('express');
const { requireAdminKey } = require('../middleware/adminAuth');
const { trackAdminVisit, trackAdminTime } = require('../middleware/adminAnalytics');
const { readJson } = require('../utils/jsonStore');

const router = express.Router();

// Return aggregate admin analytics values from analytics.json.
router.get('/', requireAdminKey, (req, res) => {
    const analytics = readJson('analytics.json', { visits: 0, totalTimeMs: 0 });
    res.json(analytics);
});

// Register one admin dashboard session visit.
router.post('/session/start', requireAdminKey, trackAdminVisit, (req, res) => {
    const analytics = readJson('analytics.json', { visits: 0, totalTimeMs: 0 });
    res.json(analytics);
});

// Add session duration to total accumulated admin time.
router.post('/session/end', requireAdminKey, trackAdminTime, (req, res) => {
    const analytics = readJson('analytics.json', { visits: 0, totalTimeMs: 0 });
    res.json(analytics);
});

module.exports = router;
