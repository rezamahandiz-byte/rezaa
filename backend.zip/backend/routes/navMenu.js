const createCrudRouter = require('./createCrudRouter');

// Admin CRUD routes for NavBar about-menu items in navMenu.json.
module.exports = createCrudRouter('navMenu.json');
