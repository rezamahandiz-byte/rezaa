const express = require('express');
const { readJson, writeJson } = require('../utils/jsonStore');
const { slugify, uniqueSlug } = require('../utils/slug');
const { logEvent } = require('../utils/logger');

const router = express.Router();
const SONGS_FILE = 'songs.json';

// Normalize any incoming payload to a plain object to avoid undefined/null crashes.
function normalizePayload(payload) {
    return payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
}

// Read songs from JSON storage (fs-backed through jsonStore).
function readSongs() {
    return readJson(SONGS_FILE, []);
}

// Persist songs to songs.json after every CRUD write operation.
function saveSongs(items) {
    writeJson(SONGS_FILE, items);
}

// Generate a stable public song path from title/id and keep it unique.
function buildSongPath(items, payload, existingId = null) {
    const safePayload = normalizePayload(payload);
    const rawTitle = safePayload.MiusicTitle || safePayload.title || '';
    const base = slugify(rawTitle) || `song-${existingId || Date.now()}`;
    const slug = uniqueSlug(base, (candidate) =>
        items.some((song) => song.slug === candidate && Number(song.id) !== Number(existingId))
    );
    return { slug, path: `/song/${slug}` };
}

// Backfill slug/path for legacy songs and persist once when missing.
function ensureSongRoutes(items) {
    let changed = false;
    const next = items.map((song) => {
        if (song.slug && song.path) return song;
        const { slug, path } = buildSongPath(items, song, song.id);
        changed = true;
        return { ...song, slug, path };
    });
    if (changed) saveSongs(next);
    return next;
}

// GET all songs for admin list management.
router.get('/', (req, res) => {
    logEvent('songs.list.requested');
    res.json(ensureSongRoutes(readSongs()));
});

// POST create song and persist generated slug/path into JSON.
router.post('/', (req, res) => {
    const items = ensureSongRoutes(readSongs());
    const payload = normalizePayload(req.body);

    if (!String(payload.MiusicTitle || '').trim()) {
        logEvent('songs.create.invalid_payload', {
            reason: 'MiusicTitle is required',
            bodyType: typeof req.body,
        });
        return res.status(400).json({ message: 'عنوان آهنگ الزامی است.' });
    }

    const nextId = items.length ? Math.max(...items.map((i) => Number(i.id) || 0)) + 1 : 1;
    const { slug, path } = buildSongPath(items, payload);
    const item = { id: nextId, ...payload, slug, path };
    items.push(item);
    saveSongs(items);
    logEvent('songs.created', {
        id: item.id,
        title: item.MiusicTitle || '',
        slug: item.slug,
    });
    res.status(201).json(item);
});

// PUT update song and regenerate slug/path when title changes.
router.put('/:id', (req, res) => {
    const id = Number(req.params.id);
    const items = ensureSongRoutes(readSongs());
    const payload = normalizePayload(req.body);
    const index = items.findIndex((song) => Number(song.id) === id);

    if (index < 0) {
        logEvent('songs.update.not_found', { id });
        return res.status(404).json({ message: 'آهنگ پیدا نشد.' });
    }

    const previous = items[index];
    const merged = { ...previous, ...payload, id };
    const titleChanged = (previous.MiusicTitle || '') !== (merged.MiusicTitle || '');
    const routeChanged = titleChanged || !merged.slug || !merged.path;

    if (routeChanged) {
        const { slug, path } = buildSongPath(items, merged, id);
        merged.slug = slug;
        merged.path = path;
    }

    items[index] = merged;
    saveSongs(items);
    logEvent('songs.updated', {
        id: merged.id,
        title: merged.MiusicTitle || '',
        slug: merged.slug || '',
    });
    return res.json(merged);
});

// DELETE remove song from JSON file by id.
router.delete('/:id', (req, res) => {
    const id = Number(req.params.id);
    const items = ensureSongRoutes(readSongs());
    const next = items.filter((song) => Number(song.id) !== id);
    saveSongs(next);
    logEvent('songs.deleted', { id });
    res.json({ success: true });
});

module.exports = router;
