const express = require('express');
const { readJson, writeJson } = require('../utils/jsonStore');
const { logEvent } = require('../utils/logger');

const router = express.Router();
const ADS_FILE = 'ads.json';

// Normalize any incoming payload to a plain object to avoid undefined/null writes.
function normalizePayload(payload) {
    return payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
}

// Read all ads from fs-backed JSON storage.
function readAds() {
    return readJson(ADS_FILE, []);
}

// Persist ad changes to ads.json after every mutation.
function saveAds(items) {
    writeJson(ADS_FILE, items);
}

// GET all ads for admin table rendering.
router.get('/', (req, res) => {
    logEvent('ads.list.requested');
    res.json(readAds());
});

// POST create ad and write to ads.json.
router.post('/', (req, res) => {
    const items = readAds();
    const payload = normalizePayload(req.body);

    if (!String(payload.AdverTitle || '').trim()) {
        logEvent('ads.create.invalid_payload', {
            reason: 'AdverTitle is required',
            bodyType: typeof req.body,
        });
        return res.status(400).json({ message: 'عنوان تبلیغ الزامی است.' });
    }

    const nextId = items.length ? Math.max(...items.map((i) => Number(i.id) || 0)) + 1 : 1;
    const item = { id: nextId, ...payload };
    items.push(item);
    saveAds(items);
    logEvent('ads.created', { id: item.id, title: item.AdverTitle || '' });
    res.status(201).json(item);
});

// PUT update ad by id and persist to ads.json.
router.put('/:id', (req, res) => {
    const id = Number(req.params.id);
    const items = readAds();
    const payload = normalizePayload(req.body);
    const index = items.findIndex((ad) => Number(ad.id) === id);

    if (index < 0) {
        logEvent('ads.update.not_found', { id });
        return res.status(404).json({ message: 'تبلیغ پیدا نشد.' });
    }

    const merged = { ...items[index], ...payload, id };
    items[index] = merged;
    saveAds(items);
    logEvent('ads.updated', { id: merged.id, title: merged.AdverTitle || '' });
    return res.json(merged);
});

// DELETE ad by id and persist the remaining list.
router.delete('/:id', (req, res) => {
    const id = Number(req.params.id);
    const items = readAds();
    const next = items.filter((ad) => Number(ad.id) !== id);
    saveAds(next);
    logEvent('ads.deleted', { id });
    res.json({ success: true });
});

module.exports = router;
